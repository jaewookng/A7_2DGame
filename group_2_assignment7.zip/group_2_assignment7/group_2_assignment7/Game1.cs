﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace group_2_assignment7
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        // GLOBAL GAME STATE & UI
        private SpriteFont _guiFont;
        private bool _isGameOver = false;
        private bool _isVictory = false;
        
        // DHARMA'S ENEMY VARIABLES
        private List<Enemy> _enemies;
        private Texture2D _enemyTexture;
        private Texture2D _blankTexture;
        private float _enemySpawnTimer = 0f; // the "additional feature timer" requirement
        
        //JAEWOO'S PLAYER PLACEHOLDERS
        // public Sprite _player; 
        private int _playerFakeHP = 5; // temporary variable until Jaewoo makes his class
        
        // XINLIN'S ENVIRONMENT PLACEHOLDERS
        // public Environment _level;
        private List<Rectangle> _fakeTerrain; // temporary variable until Xinlin makes her class

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferWidth = 800;
            _graphics.PreferredBackBufferHeight = 600;
            _graphics.ApplyChanges();

            _enemies = new List<Enemy>();

            // XINLIN'S CODE HERE
            // _level = new Environment();
            // for now, we use fake terrain
            _fakeTerrain = new List<Rectangle>() 
            {
                new Rectangle(0, 500, 800, 100), //main floor
                new Rectangle(300, 450, 100, 50) //small jump obstacle
            };

            // JAEWOO'S CODE HERE
            // _player = new Sprite(new Vector2(100, 400));

            //spawn an initial enemy to test
            _enemies.Add(new Enemy(new Vector2(600, 100)));

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            
            //load Font for GUI
            _guiFont = Content.Load<SpriteFont>("DefaultFont");

            // DHARMA'S CODE
            _enemyTexture = Content.Load<Texture2D>("50054d2b-242e-47f8-9ff4-911adb4c5e13 (1)");
            _blankTexture = new Texture2D(GraphicsDevice, 1, 1);
            _blankTexture.SetData(new[] { Color.White });
            
            // JAEWOO & XINLIN'S CODE HERE
            // _player.LoadContent(Content);
            // _level.LoadContent(Content);
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            //freeze the game if the player wins or loses
            if (_isGameOver || _isVictory) return;

            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // JAEWOO'S CODE HERE
            // _player.Update(gameTime);
            
            // DUMMY PLAYER DATA for Dharma to test Enemy tracking (follows the mouse)
            MouseState mouseState = Mouse.GetState();
            Vector2 currentPlayerPos = new Vector2(mouseState.X, mouseState.Y);
            Rectangle currentPlayerHitbox = new Rectangle(mouseState.X, mouseState.Y, 32, 32);

            // XINLIN'S CODE HERE
            // _level.Update(gameTime, currentPlayerPos); 
            // List<Rectangle> activeTerrain = _level.GetHitboxes();
            
            // DUMMY TERRAIN DATA
            List<Rectangle> activeTerrain = _fakeTerrain;


            // DHARMA'S CODE: ENEMY UPDATES
            
            // spawner timer Logic
            _enemySpawnTimer += deltaTime;
            if (_enemySpawnTimer >= 10f && _enemies.Count < 5) //spawn a new enemy every 10 seconds, max 5
            {
                _enemies.Add(new Enemy(new Vector2(800, 100))); //spawn off right side of screen
                _enemySpawnTimer = 0f;
            }

            //update all existing enemies
            for (int i = _enemies.Count - 1; i >= 0; i--)
            {
                //we pass in the dummy data... later, change this to _player.Position, _player.Hitbox, activeTerrain
                bool didHitPlayer = _enemies[i].Update(gameTime, currentPlayerPos, currentPlayerHitbox, activeTerrain);

                //combat logic
                if (didHitPlayer)
                {
                    _playerFakeHP--; //later: _player.TakeDamage(1);
                }

                //if Jaewoo's player attacks and hits the enemy hitbox, remove the enemy
                //example of future integration:
                //if (_player.IsAttacking && _player.AttackHitbox.Intersects(_enemies[i].Hitbox)) { _enemies[i].TakeDamage(1); }
                
                //remove dead enemies
                if (_enemies[i].HealthPoints <= 0)
                {
                    _enemies.RemoveAt(i);
                }
            }


            //WIN / LOSE CONDITIONS (GUI REQUIREMENT)
            if (_playerFakeHP <= 0)
            {
                _isGameOver = true;
            }
            //win condition: Survived the waves and killed all enemies
            else if (_enemies.Count == 0 && _enemySpawnTimer < 0f) //modify logic based on final level design
            {
                _isVictory = true;
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();

            //XINLIN'S CODE HERE
            //_level.Draw(_spriteBatch);
            
            //draw Fake Terrain for testing
            foreach(var rect in _fakeTerrain)
            {
                //just draws a blank white square to represent terrain
                _spriteBatch.Draw(_blankTexture, rect, Color.Green); 
            }

            //JAEWOO'S CODE HERE
            //_player.Draw(_spriteBatch);

            //DHARMA'S CODE: ENEMY DRAW
            foreach (var enemy in _enemies)
            {
                //if no texture yet, this will crash, comment it out if testing just logic.
                enemy.Draw(_spriteBatch, _enemyTexture);
            }

            //GUI / HUD REQUIREMENT
            _spriteBatch.DrawString(_guiFont, "Player HP: " + _playerFakeHP, new Vector2(20, 20), Color.Red);

            if (_isGameOver)
            {
                _spriteBatch.DrawString(_guiFont, "GAME OVER! You Died.", new Vector2(300, 250), Color.Red);
            }
            else if (_isVictory)
            {
                _spriteBatch.DrawString(_guiFont, "VICTORY! All Enemies Defeated.", new Vector2(280, 250), Color.Gold);
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}